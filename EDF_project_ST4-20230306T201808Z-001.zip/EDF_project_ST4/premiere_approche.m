%% Data of the problem

h_min=0.5;
h_max=7.5;

%% Importation of data 

opts = spreadsheetImportOptions("NumVariables", 3);

% Specify sheet and range
opts.Sheet = "Donn�es d�bit-hauteur";
opts.DataRange = "A2:C150";

% Specify column names and types
opts.VariableNames = ["Annee", "Debit_max", "Hauteur_associee"];
opts.SelectedVariableNames = ["Annee", "Debit_max", "Hauteur_associee"];
opts.VariableTypes = ["double", "double", "double"];

% Import the data
Donnees = readtable("C:\Users\louis\Documents\GSI\EI EDF\Donn�es-projet-EDF_2018-2019.xls", opts, "UseExcel", false);

% Clear temporary variables
clear opts
clf

%% Interpolation of the associated height

Donnees_triees = sortrows(Donnees, 2);

figure(1)

xlabel('Q the max flow')
ylabel('H the associated water height')
title('Observed and interpolated data')

hold on
plot(Donnees_triees.Debit_max, Donnees_triees.Hauteur_associee,'*b')

Index_Interp = find(isnan(Donnees_triees.Hauteur_associee)==1);      %Index of NaN values
Index_Valeurs = find(isnan(Donnees_triees.Hauteur_associee)==0);     %Index of complete values

% The method of interpolation can be 'linear', 'nearest', 'next', 'previous', 'pchip', 'cubic', 'v5cubic', 'makima', or 'spline'

method = 'linear';    %linear or pchip
Interp = interp1(Donnees_triees.Debit_max(Index_Valeurs), Donnees_triees.Hauteur_associee(Index_Valeurs), Donnees_triees.Debit_max(Index_Interp), method);

plot(Donnees_triees.Debit_max(Index_Interp), Interp,'*r')
hold off

legend('Exact values', 'Interpolated values', 'Location','northwest')

H = [transpose(Donnees_triees.Hauteur_associee(Index_Valeurs)), transpose(Interp)];

%% Model of H

H = H(:);

figure(2);
clf;
hold on;

% --- Plot data originally in dataset "H data"
[CdfF,CdfX] = ecdf(H,'Function','cdf');  % compute empirical cdf
BinInfo.rule = 1;
[~,BinEdge] = internal.stats.histbins(H,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);
hLine = bar(BinCenter,BinHeight,'hist');
set(hLine,'FaceColor','none','EdgeColor',[0.333333 0 0.666667],'LineStyle','-', 'LineWidth',1);
xlabel('Empirical and interpolated values of H');
ylabel('Density')

% Create grid where function will be computed
XLim = get(gca,'XLim');
XLim = XLim + [-1 1] * 0.01 * diff(XLim);
XGrid = linspace(XLim(1),XLim(2),100);

pd = fitdist(H, 'normal');
YPlot = pdf(pd,XGrid);
hLine = plot(XGrid,YPlot,'-r', 'LineWidth',2,'MarkerSize',6);

box on;
hold off;

legend('Histogram of H', 'normal fit')
title('Fit model of the maximum water level H')

range=h_min:0.001:h_max;
p=proba(pd,range);

figure(3);
clf;
hold on
xlabel('Height of the dike h_d (in m)')
ylabel('Probability of overflow')

plot(range,p,'-c','Linewidth',2)
    
%% Estimation of h_d

proba_interp=[];
proba_sans_interp=[];

for h=range
    
    proba_interp=[proba_interp, sum(H-h>=0)/length(H)];
    proba_sans_interp=[proba_sans_interp, sum(Donnees_triees.Hauteur_associee(Index_Valeurs)-h>=0)/length(Donnees_triees.Hauteur_associee(Index_Valeurs))];
        
end

plot(range,proba_interp,'.b','MarkerSize',9)
plot(range,proba_sans_interp,'.r','MarkerSize',4)

title('The probability of overflow p according to the height of the dike h_d')
legend('According to the model','With interpolated values','Without interpolated values')

hold off

err_interp=abs(p-proba_interp).^2;
RMSE_interp=sqrt(sum(err_interp)/length(range))

err=abs(p-proba_sans_interp).^2;
RMSE=sqrt(sum(err)/length(range))

%% Determining h_d according to p

[xData, yData] = prepareCurveData( range, proba_interp );

ft = fittype( 'gauss2' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Lower = [-Inf -Inf 0 -Inf -Inf 0];
opts.Normalize = 'on';
opts.StartPoint = [0.993288590604027 -1.48429691807654 0.404577791953549 0.864996789640738 -0.74214845903827 0.265836648063735];
[fitresult, gof] = fit( xData, yData, ft, opts );

figure( 'Name', 'fit 1' );
hold on
xlabel( 'Height of the dike h_d (in m)');
ylabel( 'Probability of overflow p' );
grid on

plot(xData, yData, '.b')
plot( range,fitresult(range),'-r','Linewidth',2)
plot(range,p,'-c','Linewidth',2)

legend('Empirical function of probability','Fitted curve', 'Model from the normal distribution of H')
title('Comparison of the two approaches')
hold off

%{
% Plot fit with data.
figure(5);
clf

hold on
plot(range,proba_interp,'.b')
plot(fitresult_gauss2,'-g');

xlabel('h_d the height of the dike (in m)')
ylabel('p the probability of an overflow')
title('Model fit')
legend('p=f(h_b)','model fit')
hold off
%}
%% Function defining the height of the dike according to the probability of risk

prob=fitresult(range);
h=transpose(range);
model=table(h,prob);

hb1=height1(pd,0.1)
hb2=height2(0.1,model)

function p = proba(pd,h_d)
    p=1-cdf(pd,h_d);
end

function h_d = height1(pd,p)
    h_d=icdf(pd,1-p);
end

function h_b = height2(p,model)

    e=min(abs(model.prob-p));
    i=find(abs(model.prob-p)==e);
    h_b=model.h(i);
    
end
