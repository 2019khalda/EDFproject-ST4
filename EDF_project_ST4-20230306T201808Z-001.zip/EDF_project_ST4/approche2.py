import numpy.random as npr
import math as m
import matplotlib.pyplot as plt
import numpy as np

L=5000
B=300
Zb=55.5
n= 10000  #size

Q= npr.gumbel(1013,558,n)
Ks= npr.normal(30,7.5,n)
Zv= npr.triangular(49,50,51,n)
Zm= npr.triangular(54,55,56,n)

H=[]
for k in range (0,n):
    H.append((Q[k]/(Ks[k]*B*m.sqrt((Zm[k]-Zv[k])/L)))**(3/5))

h= np.linspace(1,10,100)
P=[]
for h_d in h:
    j=0
    for i in range(0,n):
        if Zv[i] + H[i] - Zb > h_d:
            j+=1
    P.append(j/n)
plt.plot(h,P,"r")
plt.xlabel("dike height")
plt.ylabel("probability of overflow")
plt.show()

# height dike in function of risk level
def f(alpha):
    if alpha > P[0]:
        return 0
    i=0
    while alpha < P[i]:
        i+=1
    return h[i]

# graph of height of the dike with the risk level. 
Alpha=np.linspace(0,0.005,1000)
F=[f(alpha) for alpha in Alpha]
plt.plot(Alpha,F)
plt.xlabel("risk level")
plt.ylabel("dike height")
plt.title("dike height = f(risk level)")
plt.show()







