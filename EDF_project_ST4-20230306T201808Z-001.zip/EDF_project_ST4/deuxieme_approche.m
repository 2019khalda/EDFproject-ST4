
%% Variables of the problem

%Exact values

h_min=0.5;
h_max=7.5;
L=5000;
B=300;
Zb=55.5;

N=6000;

%Evaluate H

S_est=[];

for k=0:1:N
    
    Q=random(makedist('ExtremeValue','mu',1013,'sigma',558));

    Ks=random(makedist('Normal','mu',30,'sigma',7.5));

    Zv=random(makedist('Triangular','a',49,'b',50,'c',51));
    Zm=random(makedist('Triangular','a',54,'b',55,'c',56));
    
    m_slope=max(0,(Zm-Zv)/L);
    H=(Q/(Ks*sqrt(m_slope)*B))^(3/5);
    
    S_est=[S_est, -real(Zv+H-Zb)];
    
end

%% Estimation

S_est = S_est(:);

clf;
hold on;

% --- Plot data originally in dataset "S_est data"
[CdfF,CdfX] = ecdf(S_est,'Function','cdf');  % compute empirical cdf
BinInfo.rule = 1;
[~,BinEdge] = internal.stats.histbins(S_est,[],[],BinInfo,CdfF,CdfX);
[BinHeight,BinCenter] = ecdfhist(CdfF,CdfX,'edges',BinEdge);
hLine = bar(BinCenter,BinHeight,'hist');
set(hLine,'FaceColor','none','EdgeColor',[0.333333 0 0.666667],'LineStyle','-', 'LineWidth',1);
xlabel('Height of overflow without a dike (in m)');
ylabel('Density')

% Create grid where function will be computed
XLim = get(gca,'XLim');
XLim = XLim + [-1 1] * 0.01 * diff(XLim);
XGrid = linspace(XLim(1),XLim(2),100);

%{
Excluded = (S_est > -5.5);
Data = S_est(Excluded);
pd1 = fitdist(Data, 'normal');
YPlot = pdf(pd1,XGrid);
hLine = plot(XGrid,YPlot,'-r', 'LineWidth',2,'MarkerSize',6);

Excluded = (S_est < -4.7);
Data = S_est(Excluded);
pd2 = fitdist(Data, 'normal');
YPlot = pdf(pd2,XGrid);
hLine = plot(XGrid,YPlot,'-b', 'LineWidth',2,'MarkerSize',6);
%}

pd=fitdist(S_est, 'normal');
YPlot = pdf(pd,XGrid);
plot(XGrid,YPlot,'-b', 'LineWidth',2,'MarkerSize',6)

box on;
hold off;

legend('Histogram of S', 'normal fit')

%% Probability law

range=h_min:0.001:h_max;
p=proba(pd,range);

plot(range,p,'-c','Linewidth',2)

%Function calculating the probability of overflow according to hd
function p = proba(pd,h_d)
    p=1-cdf(pd,h_d);
end

%Function calculating hd according to the level of risk p
function h_d = height(pd,p)
    h_d=icdf(pd,1-p);
end
