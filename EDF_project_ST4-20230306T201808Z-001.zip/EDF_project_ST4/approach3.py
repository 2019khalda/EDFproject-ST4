from math import *
import numpy.random as npr
import matplotlib.pyplot as plt
import numpy as np
'''
#with tables as first attempt for testing with only given data
Cost_investT = {0:0, 0.1:1000000, 0.5:225000, 1:1034000, 2:4750000, 3:11023000, 4:16971000, 5:21692000, 6:26509000, 7:31408000, 8:36377000, 9:41409000, 10:46498000}
Cost_dam_siteT = {-0.1:0, 0:0, 0.5:150000000, 1:1500000000, 1,5:2000000000, 2:2000000000}
Dam_percentT = {-0.1:0, 0:0.1, 0.5:0.5, 1:1, 1,5:1, 2:1}
'''


def cost_dike(height_dike, Time): 
    if height_dike <= 0:
        lenght = 0
    elif height_dike >= 3:
        lenght = 5000
    else:
        #lenght = 1668 * height_dike #linear approximation
        lenght = 2886,8 * (height_dike**(1/2)) #better (best one in my opinion because shifted logarithm does not rise in generalas quickly between 0 and 1) approximation
    #Linear_cost = (928,5 * height_dike) #linear approximation
    Linear_cost = 92,85 * (height_dike**2) #better approximation
    Cost_invest = Linear_cost * lenght
    return Cost_invest

def cost_total(height_dike, Time):
    Cost_tot = 0
    Cost_tot = cost_dike(height_dike, Time) * 1000  + Time * 0.01*cost_dike(height_dike, Time) * 1000
    return Cost_tot

def cost_damage(overflow, hd, Time):
    #function for damage calculation
    print(hd)
    height_dike = hd
    if overflow <=0:
        Cost_dam_site = 0
    else:
        Cost_dam_site = 1500 * (overflow ** 3.3)
    if Cost_dam_site >= 2000:
        Cost_dam_site = 2000
    if overflow <= -0.1:
        percent = 0
    else: 
        percent =  overflow + 0.1
    if percent >= 1:
        percent = 1
    cd = cost_dike(height_dike, Time)
    Cost_dam_dike = percent * cd
    Cost_dam = Cost_dam_site * 1000000 + abs(Cost_dam_dike)
    return Cost_dam

def cost_year(overflowvec, height_dike, Time):
    i = 0
    Cost_dam_all = 0
    for i in range (0, Time):
        overflow = overflowvec[i]
        Cost_dam_all += cost_damage(overflow, height_dike, Time)
        i += 1
    Cost_yearly = cost_total(height_dike, Time) + Cost_dam_all
    
    return Cost_yearly

def main_func(overflowvec, height_dike):
    # Time = 30 option if time interval should only be 30 years
    Time = input("Please enter a time interval bigger than 0:") 
    Time = int(Time)
    if Time%1 != 0 or Time <= 0:            #if time interval invalid set time interval to thirty
        Time = 30
    if 0 <= height_dike <= 10:
        Cost = cost_year(overflowvec, height_dike, Time) / Time
        return Cost
    else:
        print ("Please choose height of the dike between 0 and 10 meters")
        return 0



'''
#first attemt
    height_dike = 0
    k=0
    h=0
    o=0
    j=0
    for height_dike in range (0, 10):
        height_dike += 0.01
        for overflow :#insert connection to second approach here 
'''

def approach2(n):
    L=5000
    B=300
    Zb=55.5
    # n = 30 option if time interval should only be 30 years
    n = input("Please enter a time interval bigger than 0: ") 
    n = int(n)
    if n%1 != 0 or n <= 0:            #if time interval invalid set time interval to thirty
        n = 30 #size

    Q= npr.gumbel(1013,558,n)
    Ks= npr.normal(30,7.5,n)
    Zv= npr.triangular(49,50,51,n)
    Zm= npr.triangular(54,55,56,n)

    H=[]
    for k in range (0,n):
        H.append((Q[k]/(Ks[k]*B*sqrt((Zm[k]-Zv[k])/L)))**(3/5))

    h= np.linspace(0,10,66)
    P=[]
    costmin = 0
    cost1 = 0
    cost2 =0 
    heightofdike = 0
    overflowvec2 = 0
    overflowvec=[]
    l=0
    for l in range(0,65):
        hd = h[l]
        print(hd)
        j=0
        for i in range(0,n):
            if Zv[i] + H[i] - Zb > hd:
                j+=1
            overflowvec.append( Zv[i] + H[i] - Zb - hd)
        P.append(j/n) 
        Cost_dam_year = []
        for g in range (0, n):
            overflow = overflowvec[g]
            Cost_dam_year.append(cost_damage(overflow, int(hd), n))
            g += 1
        cost2 = cost_total(hd, n) + Cost_dam_year*P
        if cost2 < cost1:
            costmin = cost2
            heightofdike = hd
            overflowvec2 = overflowvec
        cost1 = cost2
        hd += 0.1
        l+=1
    
    h2 = np.linspace(0,10,66)
    c2 = cost_year(overflowvec2, h2, n)/n
    plt.plot(h2,c2,)
    plt.xlabel("heigth of the dike")
    plt.ylabel("total cost")
    plt.show()

    total_minimal_cost = cost_year(overflowvec2, heightofdike, n)
    yearly_minimal_cost_mean = cost_year(overflowvec2, heightofdike, n)/n
    return [total_minimal_cost, yearly_minimal_cost_mean]
    
'''
def plot(h,P):
    
    plt.plot(h,P,"r")
    plt.xlabel("dike height")
    plt.ylabel("probability of overflow")
    plt.show()

    # graph of height of the dike with the risk level. 
    Alpha=np.linspace(0,0.005,1000)
    F=[f(alpha) for alpha in Alpha]
    plt.plot(Alpha,F)
    plt.xlabel("risk level")
    plt.ylabel("dike height")
    plt.title("dike height = f(risk level)")
    plt.show()
    

    # height dike in function of risk level
def f(alpha, P):
    if alpha > P[0]:
        return 0
    i=0
    while alpha < P[i]:
        i+=1
    return h[i]
'''
print(approach2(1))